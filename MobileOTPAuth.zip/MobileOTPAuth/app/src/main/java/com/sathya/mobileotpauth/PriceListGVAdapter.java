package com.sathya.mobileotpauth;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.SimpleDateFormat;
import android.icu.util.TimeZone;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.sathya.mobileotpauth.dbConnectivity.PastRidesDbHelper;
import com.sathya.mobileotpauth.dbConnectivity.RidesSchema;
import com.sathya.mobileotpauth.helper.KeyboardFragment;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class PriceListGVAdapter extends ArrayAdapter<RideModel> {
    KeyboardFragment.ConnectorForCallback callbackToMapsActivity;
    Context context;

    public PriceListGVAdapter(@NonNull Context context, ArrayList<RideModel> rideModelArrayList,
                              KeyboardFragment.ConnectorForCallback callbackToMapsActivity) {
        super(context, 0, rideModelArrayList);
        this.context = context;
        this.callbackToMapsActivity = callbackToMapsActivity;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listitemView = convertView;
        if (listitemView == null) {
            // Layout Inflater inflates each item to be displayed in GridView.
            listitemView = LayoutInflater.from(getContext()).inflate(R.layout.card_item, parent, false);
        }

        RideModel rideModel = getItem(position);
        TextView courseTV = listitemView.findViewById(R.id.idTVPrice);
        ImageView courseIV = listitemView.findViewById(R.id.idIVprice);
        courseTV.setText(rideModel.getType()+" E.P. : ₹ "+ rideModel.getPrice());
        courseIV.setImageResource(rideModel.getImgid());
        listitemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //Current Date & Time
                Date presentTime_Date = Calendar.getInstance().getTime();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+5:30"));
                String dateTime = dateFormat.format(presentTime_Date);
                Log.d("tag","DateTime :: "+dateTime);


                //Driver Details Generation
                Random rand = new Random();

                String phone = "+919"+(rand.nextInt(9)+1)+""+
                        (rand.nextInt(9)+1)+""+
                        (rand.nextInt(9)+1)+
                        "123456";
                String cabNumber = "XX-"+(rand.nextInt(9)+1)+""+(rand.nextInt(9)+1)
                        +"X-"+(rand.nextInt(9)+1)+""+(rand.nextInt(9)+1)+"67";

                String driverDetails = "TestDriver"+rand.nextInt(9)+1;


                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        //Inserting rides into database
                        PastRidesDbHelper dbHelper = new PastRidesDbHelper(context.getApplicationContext());
                        // Gets the data repository in write mode
                        SQLiteDatabase db = dbHelper.getWritableDatabase();

                        // Create a new map of values, where column names are the keys
                        ContentValues values = new ContentValues();
                        values.put(RidesSchema.PastRides.COLUMN_NAME_FROM, rideModel.getFrom());
                        values.put(RidesSchema.PastRides.COLUMN_NAME_TO, rideModel.getTo());
                        values.put(RidesSchema.PastRides.COLUMN_NAME_PRICE, rideModel.getPrice());
                        values.put(RidesSchema.PastRides.COLUMN_NAME_TYPE, rideModel.getType());
                        values.put(RidesSchema.PastRides.COLUMN_NAME_DATE, dateTime);
                        values.put(RidesSchema.PastRides.COLUMN_NAME_DRIVER, driverDetails+
                                " Cab Number: "+cabNumber+
                                " Ph No: "+phone);

                        // Insert the new row, returning the primary key value of the new row
                        long newRowId = db.insert(RidesSchema.PastRides.TABLE_NAME, null, values);
                    }
                }).start();

//                NotificationBuildHelper.createNotification("");
                //Invoke Billing
                Intent intent = new Intent(context, BookedView.class);
                intent.putExtra(RideModel.PRICE, ""+ rideModel.getPrice());
                intent.putExtra(RideModel.TYPE, rideModel.getType());
                intent.putExtra(RideModel.FROM, rideModel.getFrom());
                intent.putExtra(RideModel.TO, rideModel.getTo());
                intent.putExtra("D_DETAILS", driverDetails);
                intent.putExtra("PHONE", phone);
                intent.putExtra("CAB", cabNumber);
                context.startActivity(intent);
                callbackToMapsActivity.update(1);
            }
        });
        return listitemView;
    }
}