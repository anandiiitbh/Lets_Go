package com.sathya.mobileotpauth;

import androidx.fragment.app.FragmentActivity;

import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.sathya.mobileotpauth.helper.KeyboardFragment;

import java.util.ArrayList;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, KeyboardFragment.ConnectorForCallback {

    private GoogleMap mMap;
    private LatLng mOrigin;
    private LatLng mDestination;
    GridView coursesGV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_maps);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);
        mOrigin = new LatLng(getIntent().getDoubleExtra("S_LATITUDE",12),getIntent().getDoubleExtra("S_LONGITUDE",12));
        mDestination = new LatLng(getIntent().getDoubleExtra("D_LATITUDE",12),getIntent().getDoubleExtra("D_LONGITUDE",12));
        Log.d("tag",mOrigin.toString());
        Log.d("tag",mDestination.toString());
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        MarkerOptions optionSrc = new MarkerOptions();
        optionSrc.position(mOrigin);
        optionSrc.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
        Marker markSrc = mMap.addMarker(optionSrc);
        MarkerOptions optionDest = new MarkerOptions();
        optionDest.position(mDestination);
        optionDest.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
        Marker markDest = mMap.addMarker(optionDest);
        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        builder.include(mOrigin);
        builder.include(mDestination);
        LatLngBounds bounds = builder.build();

        int width = getResources().getDisplayMetrics().widthPixels;
        int height = getResources().getDisplayMetrics().heightPixels/3;
        int padding = (int) (width * 0.12); // offset from edges of the map 12% of screen


        CameraUpdate cameraUpdate;
        cameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds,width, height, padding);
        mMap.animateCamera(cameraUpdate);

        //Distance between Src and Dest
        Location locationA = new Location("Source ");
        locationA.setLatitude(mOrigin.latitude);
        locationA.setLongitude(mOrigin.longitude);

        Location locationB = new Location("Dest ");
        locationB.setLatitude(mDestination.latitude);
        locationB.setLongitude(mDestination.longitude);
        float distance = locationA.distanceTo(locationB)/1000;
        distance += (distance*0.3);

        ((TextView) findViewById(R.id.distance)).setText("Estimated Distance: "+String.format("%.02f", distance)+" Kms");
        ((TextView) findViewById(R.id.from)).setText(getIntent().getStringExtra("SRC"));
        ((TextView) findViewById(R.id.to)).setText(getIntent().getStringExtra("DEST"));

        Integer primeSedan = 55 + (7*(int)distance);
        Integer sedan      = 40 + (6*(int)distance);
        Integer auto       = 50 + (6*(int)distance);
        Integer bike       = 19 + (3 * (int)distance);

        if(distance > 20){
            // Base fare + travel chargers before 20 km + travel chargers after 20 km
            primeSedan = 55 + (7*20) + (((int)distance - 20) * 13);
            sedan      = 40 + (6*20) + (((int)distance - 20) * 12);
            auto       = 50 + (6*20) + (((int)distance - 20) * 12);
            bike       = 19 + (3 * (int)distance);
        }
        //Booking Options
        coursesGV = findViewById(R.id.idGVcourses);

        ArrayList<RideModel> rideModelArrayList = new ArrayList<RideModel>();
//        String price, String type, String from, String to, int imgid
        rideModelArrayList.add(new RideModel(
                primeSedan.toString(),
                "Prime Sedan",
                getIntent().getStringExtra("SRC"),
                getIntent().getStringExtra("DEST"),
                R.drawable.prime_sedan));
        rideModelArrayList.add(new RideModel(
                sedan.toString(),
                "Sedan",
                getIntent().getStringExtra("SRC"),
                getIntent().getStringExtra("DEST"),
                R.drawable.sedan));
        rideModelArrayList.add(new RideModel(
                auto.toString(),
                "Auto",
                getIntent().getStringExtra("SRC"),
                getIntent().getStringExtra("DEST"),
                R.drawable.auto));
        rideModelArrayList.add(new RideModel(
                bike.toString(),
                "Bike",
                getIntent().getStringExtra("SRC"),
                getIntent().getStringExtra("DEST"),
                R.drawable.bike));


        PriceListGVAdapter adapter = new PriceListGVAdapter(this, rideModelArrayList, this);
        coursesGV.setAdapter(adapter);
    }


    @Override
    public void update(int key) {
        finish();
    }
}