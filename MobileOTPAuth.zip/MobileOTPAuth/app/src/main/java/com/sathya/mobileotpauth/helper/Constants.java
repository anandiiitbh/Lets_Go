package com.sathya.mobileotpauth.helper;

public class Constants {
    public static final String MyPREFERENCES = "MyLogin";
    public static final String MOBILE    = "mobile";
    public static final String IS_LOGIN = "isLogin";  // value : bool true


    public static final String myBookMark = "bookmark";
    public static final String lat    = "lat";
    public static final String lng = "lng";
    public static final String isBookMarkSet    = "bookmark";


}
