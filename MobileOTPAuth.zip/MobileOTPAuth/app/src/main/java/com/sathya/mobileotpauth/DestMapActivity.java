package com.sathya.mobileotpauth;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.sathya.mobileotpauth.databinding.ActivityDestMapBinding;

import java.io.IOException;
import java.util.List;

public class DestMapActivity extends AppCompatActivity implements OnMapReadyCallback {
    private ActivityDestMapBinding binding;
    private GoogleMap mMap;
    LatLng destLocation = null;
    StringBuilder destLocationName = null;
    Marker marker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityDestMapBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.dest_view);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        mMap.getUiSettings().setZoomControlsEnabled(true);


        mMap.addMarker(new MarkerOptions()
                .position(new LatLng(getIntent().getDoubleExtra("LATITUDE",12),getIntent().getDoubleExtra("LONGITUDE",12)))
                .draggable(false)
                .flat(false));
        goToLocationZoom(getIntent().getDoubleExtra("LATITUDE",12),getIntent().getDoubleExtra("LONGITUDE",12),17);

        mMap.setOnCameraMoveListener((GoogleMap.OnCameraMoveListener) () -> {
            destLocation = mMap.getCameraPosition().target;
            setMarker();
        });

        mMap.setOnMyLocationChangeListener(new GoogleMap.OnMyLocationChangeListener() {
            @Override
            public void onMyLocationChange(Location arg0) {
                    destLocation = new LatLng(arg0.getLatitude(), arg0.getLongitude());
            }
        });
    }

    private void setMarker() {

        if (marker != null) {
            marker.remove();
            marker = null;
        }

        MarkerOptions options = new MarkerOptions()
                .position(new LatLng(destLocation.latitude,
                        destLocation.longitude))
                .draggable(false)
                .flat(false)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker));
        marker = mMap.addMarker(options);
    }

    public void LocationToReach(View view) {

        EditText editText = binding.editTextDestPlaceName;
        String location = editText.getText().toString();

        Geocoder geocoder = new Geocoder(this);  // To whom the STUB has to be provided...
        List<Address> list = null;


        try {
            list = geocoder.getFromLocationName(location, 5);

        } catch (IOException e) {
            e.printStackTrace();
        }

        Address address = list.get(0);
        editText.setText(address.getAddressLine(0));
        destLocationName = new StringBuilder(address.getAddressLine(0));

        double lat = address.getLatitude();
        double lng = address.getLongitude();

        destLocation = new LatLng(lat,lng);
        goToLocationZoom(lat, lng, 17);
        setMarker();


    }

    private void goToLocationZoom(double lat, double lng, double zoom) {
        LatLng latLng = new LatLng(lat, lng);
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, (float) zoom);
        this.mMap.moveCamera(cameraUpdate);
    }

    public void gotoBilling(View view) {
        if(destLocation!=null){
            Intent intent = new Intent(DestMapActivity.this, MapsActivity.class);
            //Source Coordinate
            intent.putExtra("S_LATITUDE", getIntent().getDoubleExtra("LATITUDE",12));
            intent.putExtra("S_LONGITUDE", getIntent().getDoubleExtra("LONGITUDE",12));
            intent.putExtra("SRC", getIntent().getStringExtra("SRC"));
            //Destination Coordinate
            intent.putExtra("D_LATITUDE", destLocation.latitude);
            intent.putExtra("D_LONGITUDE",destLocation.longitude);
            intent.putExtra("DEST", getAreaName());
            startActivity(intent);
            finish();
        }
    }

    String getAreaName(){
        Geocoder geocoder = new Geocoder(this);
        List<Address> list = null;
        try {

            Log.d("tag","Location: "+destLocation.toString());
            list = geocoder.getFromLocation(destLocation.latitude,destLocation.longitude,5);

            Log.d("tag","LocationName: "+list.get(0).toString());

        } catch (IOException e) {
            e.printStackTrace();
        }

        Address address = list.get(0);

        return address.getAddressLine(0);
    }
}