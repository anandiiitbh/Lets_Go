package com.sathya.mobileotpauth.helper;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.sathya.mobileotpauth.R;

public class BusinessLogic extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_logic);
    }
}