package com.sathya.mobileotpauth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.sathya.mobileotpauth.databinding.ActivitySourceMapBinding;
import com.sathya.mobileotpauth.helper.Constants;
import com.sathya.mobileotpauth.helper.NotificationBuildHelper;

import java.io.IOException;
import java.util.List;
import java.util.Random;

public class SourceMapActivity extends AppCompatActivity implements OnMapReadyCallback {


    private static final int LOCATION_UPDATED = 1;
    private ActivitySourceMapBinding binding;
    private static final int REQUEST_LOCATION_PERMISSION = 1;
    private GoogleMap mMap;
    private boolean isMyLocationChecked = false;
    SwitchMaterial currentLocationSwitch;
    LinearLayout sourceInput;

    LatLng myLocation = null;
    StringBuilder myLocationName = null;
    static Handler handler;
    Marker marker,markSrc,markDest;
    private SharedPreferences sharedpreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();

        binding = ActivitySourceMapBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.ghost_view);
        mapFragment.getMapAsync(this);

        currentLocationSwitch = findViewById(R.id.currentLocation);
        sourceInput = findViewById(R.id.SourceInput);



        sharedpreferences = getSharedPreferences(Constants.myBookMark, Context.MODE_PRIVATE);

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == LOCATION_UPDATED) {
                    goToLocationZoom(myLocation.latitude, myLocation.longitude, 15);
//                    Toast.makeText(SourceMapActivity.this, "Location: " + getAreaName(), Toast.LENGTH_SHORT).show();
                }
                super.handleMessage(msg);
            }
        };


    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {

        statusCheck();
        mMap = googleMap;
        enableMyLocation();
        mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        mMap.getUiSettings().setZoomControlsEnabled(true);
        enableMyLocation();

        LatLng india = new LatLng(21, 78);

//        LatLng latLng = new LatLng(lat, lng);
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(india, 3.8f);
        this.mMap.moveCamera(cameraUpdate);
//        mMap.moveCamera(CameraUpdateFactory.newLatLng(india,4.0f));

        Runnable refreshCurrentLocation = new Runnable() {
            public void run() {
                while (myLocation == null) ;
                Message msg = handler.obtainMessage();
                msg.what = LOCATION_UPDATED;
                handler.sendMessage(msg);
            }
        };


        mMap.setOnCameraMoveListener((GoogleMap.OnCameraMoveListener) () -> {
            myLocation = googleMap.getCameraPosition().target;
            setMarker();
        });

        currentLocationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                enableMyLocation();
                sourceInput.setVisibility(View.GONE);
                mMap.setOnMyLocationChangeListener(new GoogleMap.OnMyLocationChangeListener() {
                    @Override
                    public void onMyLocationChange(Location arg0) {

                        if(!isMyLocationChecked) {
                            myLocation = new LatLng(arg0.getLatitude(), arg0.getLongitude());
                            isMyLocationChecked=!isMyLocationChecked;
                            new Thread(refreshCurrentLocation).start();

                        }
                        Toast.makeText(SourceMapActivity.this, "Current Location: "+getAreaName(), Toast.LENGTH_SHORT).show();

                    }
                });
            }
            else{
                sourceInput.setVisibility(View.VISIBLE);
                isMyLocationChecked=!isMyLocationChecked;
            }
        });

    }



    public void statusCheck() {
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();

        }
    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
        } else {
            ActivityCompat.requestPermissions(this, new String[]
                            {Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_LOCATION_PERMISSION);
        }
    }

    private void goToLocationZoom(double lat, double lng, double zoom) {
        LatLng latLng = new LatLng(lat, lng);
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, (float) zoom);
        this.mMap.moveCamera(cameraUpdate);
        setMarker();

    }

    public void LocationToReach(View view) {

        EditText editText = binding.editTextTextPlaceName;
        String location = editText.getText().toString();

        Geocoder geocoder = new Geocoder(this);  // To whom the STUB has to be provided...
        List<Address> list = null;


        try {

            list = geocoder.getFromLocationName(location, 5);

        } catch (IOException e) {
            e.printStackTrace();
        }

        Address address = list.get(0);
        editText.setText(address.getAddressLine(0));
        myLocationName = new StringBuilder(address.getAddressLine(0));
        double lat = address.getLatitude();
        double lng = address.getLongitude();

        myLocation = new LatLng(lat,lng);
        goToLocationZoom(lat, lng, 17);


    }

    private void setMarker() {

        if (marker != null || markSrc!=null || markDest!=null) {
            marker.remove();
            markSrc.remove();
            markDest.remove();
            marker = null;
            markSrc=null;
            markDest=null;
        }

        MarkerOptions options = new MarkerOptions()
                .position(new LatLng(myLocation.latitude,
                        myLocation.longitude))
                .draggable(false)
                .flat(false)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker));
        marker = mMap.addMarker(options);
        getNearByLocation(myLocation.latitude,myLocation.longitude,100);

    }

    String getAreaName(){
        Geocoder geocoder = new Geocoder(this);
        List<Address> list = null;
        try {

            Log.d("tag","Location: "+myLocation.toString());
            list = geocoder.getFromLocation(myLocation.latitude,myLocation.longitude,5);

            Log.d("tag","LocationName: "+list.get(0).toString());

        } catch (IOException e) {
            e.printStackTrace();
        }

        Address address = list.get(0);
        myLocationName = new StringBuilder(address.getAddressLine(0));

        return address.getAddressLine(0);
    }

    public void gotoDestination(View view) {
        if(myLocation!=null){
            Intent intent = new Intent(SourceMapActivity.this, DestMapActivity.class);
            intent.putExtra("LATITUDE", myLocation.latitude);
            intent.putExtra("LONGITUDE", myLocation.longitude);
            intent.putExtra("SRC", myLocationName.toString());
            startActivity(intent);
        }
    }

    public void gotoPastBookings(View view) {
        Intent intent = new Intent(this, PastRideViews.class);
        startActivity(intent);
    }

    public void saveBookmark(View view) {

        if(sharedpreferences.contains(Constants.isBookMarkSet)) {
            myLocation = new LatLng(Double.parseDouble(sharedpreferences.getString(Constants.lat,"")),Double.parseDouble(sharedpreferences.getString(Constants.lng,"")));
            setMarker();
            goToLocationZoom(myLocation.latitude,myLocation.longitude,15);
            EditText editText = binding.editTextTextPlaceName;
            editText.setText(getAreaName());
        }
        else{
            if(myLocation!=null){
                Toast.makeText(getApplicationContext(),"Bookmarked this location", Toast.LENGTH_SHORT).show();
                SharedPreferences.Editor editor = sharedpreferences.edit();  // GE_HEALTH
                editor.putString(Constants.lat, String.valueOf(myLocation.latitude));
                editor.putString(Constants.lng, String.valueOf(myLocation.longitude));
                editor.putBoolean(Constants.isBookMarkSet, true);
                editor.commit();
            }

        }
    }

    LatLng getNearByLocation(double x0, double y0, int radius) {
        Random random = new Random();
        markDest=null;
        markSrc=null;


        // Convert radius from meters to degrees
        double radiusInDegrees = radius / 111000f;

        double u = random.nextDouble();
        double v = random.nextDouble();
        double w = radiusInDegrees * Math.sqrt(u);
        double t = 2 * Math.PI * v;
        double x = w * Math.cos(t);
        double y = w * Math.sin(t);

        // Adjust the x-coordinate for the shrinking of the east-west distances
        double new_x = x / Math.cos(Math.toRadians(y0));

        double foundLongitude = new_x + x0;
        double foundLatitude = y + y0;
        Log.d("tag", "my loc : "+myLocation.latitude+"..."+myLocation.longitude+"###"+foundLatitude+"  "+foundLongitude);
        //setting nearby vehicles
        MarkerOptions optionSrc = new MarkerOptions();
        optionSrc.position(new LatLng(foundLongitude,
                foundLatitude));
        optionSrc.icon(BitmapDescriptorFactory.fromResource(R.drawable.sedan1));
        markSrc = mMap.addMarker(optionSrc);
        MarkerOptions optionDest = new MarkerOptions();
        optionDest.position(new LatLng(foundLongitude,
                foundLatitude));
        optionDest.icon(BitmapDescriptorFactory.fromResource(R.drawable.sedan2));
        markDest = mMap.addMarker(optionDest);
        return new LatLng(foundLongitude,foundLatitude);
    }
}